package com.raja.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BatchConfig {
}
